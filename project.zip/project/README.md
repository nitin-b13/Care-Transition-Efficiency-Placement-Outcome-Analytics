# UAC Care Pipeline: Process Efficiency and Outcome Analysis

Everything is in this one folder. Open a terminal IN this folder, then:

1. pip install -r requirements.txt
2. python run_all.py            (runs module1 to module5; or run each module file one by one)
3. streamlit run app.py         (dashboard opens at http://localhost:8501)
4. Double-click index.html      (project page)

Files: HHS_Unaccompanied_Alien_Children_Program.csv (data) · module1_cleaning.py · module2_features.py ·
module3_eda.py · module4_kpis.py · module5_bottleneck_model.py · app.py (module 6, dashboard) ·
index.html · HHS_UAC_Research_Paper.docx · HHS_UAC_Executive_Summary.docx
Folders figures/ and outputs/ are created automatically.
